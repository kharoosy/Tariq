#!/usr/bin/env python3
"""
build_sticker_pack.py

Converts a folder of ordinary images (jpg/png/webp/anything Pillow can open)
into a WhatsApp-compliant sticker pack, and drops the result straight into
this Android project's assets/ so it's ready to build in Android Studio.

WhatsApp's hard requirements for static stickers (as of the current spec):
  - Exactly 512x512 px, WEBP format
  - File size < 100 KB per sticker
  - Tray icon: 96x96 px, PNG, < 50 KB
  - 3 to 30 stickers per pack
  - contents.json manifest describing the pack(s)

Usage:
    python3 build_sticker_pack.py --input /path/to/images \
        --pack-id 1 --pack-name "My Pack" --publisher "Tariq" \
        [--tray-image /path/to/tray_source.png]

Run with no --tray-image and the script will auto-generate a tray icon
from the first sticker.
"""

import argparse
import json
import os
import sys
from pathlib import Path

from PIL import Image

ASSETS_DIR = Path(__file__).parent / "app" / "src" / "main" / "assets"
CONTENTS_JSON = ASSETS_DIR / "contents.json"

MAX_STICKER_BYTES = 100 * 1024
MAX_TRAY_BYTES = 50 * 1024
STICKER_SIZE = (512, 512)
TRAY_SIZE = (96, 96)
MIN_STICKERS = 3
MAX_STICKERS = 30

VALID_EXT = {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".gif"}


def fit_square(img: Image.Image, size) -> Image.Image:
    """Pad (not crop) the image onto a transparent square canvas of `size`."""
    img = img.convert("RGBA")
    img.thumbnail(size, Image.LANCZOS)
    canvas = Image.new("RGBA", size, (0, 0, 0, 0))
    x = (size[0] - img.width) // 2
    y = (size[1] - img.height) // 2
    canvas.paste(img, (x, y), img)
    return canvas


def save_webp_under_limit(img: Image.Image, out_path: Path, max_bytes: int):
    """Save as WEBP, stepping quality down until it's under the byte limit."""
    for quality in (90, 80, 70, 60, 50, 40, 30, 20):
        img.save(out_path, "WEBP", quality=quality, method=6)
        if out_path.stat().st_size <= max_bytes:
            return quality
    return quality  # best effort at lowest quality tried


def save_png_under_limit(img: Image.Image, out_path: Path, max_bytes: int):
    img.save(out_path, "PNG", optimize=True)
    if out_path.stat().st_size <= max_bytes:
        return
    # PNG has no quality knob; downscale until it fits.
    w, h = img.size
    while out_path.stat().st_size > max_bytes and w > 32:
        w, h = int(w * 0.85), int(h * 0.85)
        img.resize((w, h), Image.LANCZOS).save(out_path, "PNG", optimize=True)


def build_pack(input_dir: Path, pack_id: str, pack_name: str, publisher: str,
               tray_image_src: Path | None, emoji_default: list[str],
               publisher_email: str, publisher_website: str):
    images = sorted(
        p for p in input_dir.iterdir()
        if p.suffix.lower() in VALID_EXT
    )
    if not images:
        sys.exit(f"No supported images found in {input_dir}")
    if len(images) > MAX_STICKERS:
        print(f"Warning: {len(images)} images found, WhatsApp caps a pack at "
              f"{MAX_STICKERS}. Using the first {MAX_STICKERS}.")
        images = images[:MAX_STICKERS]
    if len(images) < MIN_STICKERS:
        sys.exit(f"WhatsApp requires at least {MIN_STICKERS} stickers per "
                  f"pack, only found {len(images)}.")

    pack_dir = ASSETS_DIR / pack_id
    pack_dir.mkdir(parents=True, exist_ok=True)

    sticker_entries = []
    print(f"Converting {len(images)} images -> {pack_dir}")
    for idx, src in enumerate(images, start=1):
        out_name = f"{idx:02d}_{src.stem}.webp"
        out_path = pack_dir / out_name
        img = fit_square(Image.open(src), STICKER_SIZE)
        q = save_webp_under_limit(img, out_path, MAX_STICKER_BYTES)
        size_kb = out_path.stat().st_size / 1024
        print(f"  [{idx:02d}] {src.name} -> {out_name} "
              f"({size_kb:.1f} KB, quality={q})")
        sticker_entries.append({
            "image_file": out_name,
            "emojis": emoji_default,
            "accessibility_text": src.stem.replace("_", " ")
        })

    # Tray icon
    tray_name = f"tray_{pack_id}.png"
    tray_path = pack_dir / tray_name
    tray_source_img = Image.open(tray_image_src) if tray_image_src else Image.open(images[0])
    tray_img = fit_square(tray_source_img, TRAY_SIZE)
    save_png_under_limit(tray_img, tray_path, MAX_TRAY_BYTES)
    print(f"  Tray icon -> {tray_name} ({tray_path.stat().st_size / 1024:.1f} KB)")

    # Update contents.json
    contents = json.loads(CONTENTS_JSON.read_text())
    contents["sticker_packs"] = [
        p for p in contents["sticker_packs"] if p["identifier"] != pack_id
    ]
    contents["sticker_packs"].append({
        "identifier": pack_id,
        "name": pack_name,
        "publisher": publisher,
        "tray_image_file": tray_name,
        "image_data_version": "1",
        "avoid_cache": False,
        "publisher_email": publisher_email,
        "publisher_website": publisher_website,
        "privacy_policy_website": "",
        "license_agreement_website": "",
        "stickers": sticker_entries
    })
    CONTENTS_JSON.write_text(json.dumps(contents, indent=4, ensure_ascii=False))
    print(f"\nUpdated {CONTENTS_JSON}")
    print(f"Pack '{pack_name}' (id={pack_id}) is ready with {len(sticker_entries)} stickers.")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True, help="Folder of source images")
    ap.add_argument("--pack-id", required=True, help="Unique short id, e.g. '1'")
    ap.add_argument("--pack-name", required=True)
    ap.add_argument("--publisher", required=True)
    ap.add_argument("--tray-image", default=None, help="Optional separate tray icon source image")
    ap.add_argument("--emoji", nargs="*", default=["😀"],
                     help="Default emoji(s) tagged to every sticker (space separated)")
    ap.add_argument("--publisher-email", default="")
    ap.add_argument("--publisher-website", default="")
    args = ap.parse_args()

    build_pack(
        Path(args.input).expanduser(),
        args.pack_id,
        args.pack_name,
        args.publisher,
        Path(args.tray_image).expanduser() if args.tray_image else None,
        args.emoji,
        args.publisher_email,
        args.publisher_website,
    )
