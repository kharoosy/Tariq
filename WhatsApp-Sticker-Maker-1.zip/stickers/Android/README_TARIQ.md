# My Stickers — Android project

Why this is an Android app and not just a script: WhatsApp only accepts
stickers from an installed app that implements its sticker Content
Provider and calls the `Add to WhatsApp` intent. There's no way to just
"drop" images into WhatsApp — this project + a one-time install is the
actual mechanism WhatsApp itself documents for developers.

## 1. Get your images into the app — two ways

**A. From inside the app (no computer needed after install)**
- Launch the app → **Create sticker pack** → **Select images from device**
- Batch-pick 3–30 images straight from your gallery/files
- Give the pack a name → **Create sticker pack**
- Everything (resize to 512x512, WEBP conversion, <100KB compression, tray icon, `contents.json`) happens on-device. The pack shows up immediately — tap **Add to WhatsApp**.
- To add more packs later: open the app → menu (⋮) → **Create sticker pack**, or on a single-pack view, the same option is in the toolbar menu.

**B. From your computer, before building** (useful for bulk/scripted pack creation)
```
cd Android
pip install Pillow
python3 build_sticker_pack.py \
    --input /path/to/your/images \
    --pack-id 1 \
    --pack-name "My Pack" \
    --publisher "Tariq" \
    --emoji 😀 🎉
```
- Put 3–30 images in one folder per pack (jpg/png/webp all fine — anything Pillow opens).
- Run it again with `--pack-id 2`, `3`, etc. for more packs; each run only touches its own id.
- It resizes to 512x512, converts to WEBP, compresses under 100KB, generates a tray icon, and writes `app/src/main/assets/contents.json` automatically.
- These become permanent, bundled-in-the-APK packs (unlike option A, which stores packs in the app's private storage on the phone — both kinds show up side by side).

## 2. Open in Android Studio
- Open the `Android/` folder as a project.
- It already has a real `applicationId` (`com.tariq.mystickers`) and app name ("My Stickers") set — the sample's default values are blocked from building on purpose.
- Build & run on your phone (min SDK 15, so any device works).

## 3. Add to WhatsApp
- Launch the app once installed → tap **Add to WhatsApp** on each pack.
- Open WhatsApp → any chat → sticker icon → your pack appears there.

## Notes
- Static stickers only (this script doesn't handle animated WEBP — say the word if you want animated support added, it's a similar pipeline with a frame-duration field).
- Re-run the script any time to swap out a pack's images; it overwrites that pack's folder and its `contents.json` entry.
